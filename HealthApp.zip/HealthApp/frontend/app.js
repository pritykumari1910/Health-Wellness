document.getElementById("healthForm").onsubmit = function (e) {
    e.preventDefault();

    let age = parseInt(document.getElementById("age").value);
    let bmi = parseInt(document.getElementById("bmi").value);
    let cholesterol = parseInt(document.getElementById("cholesterol").value);
    let exercise = parseInt(document.getElementById("exercise").value);

    let cluster = "";
    
    if (bmi < 25 && exercise > 2) {
        cluster = "Active & Healthy";
        recommendation = "Maintain your diet and regular exercise!";
    } 
    else if (bmi >= 25 && cholesterol > 200) {
        cluster = "High Risk";
        recommendation = "Consult a doctor and follow a personalized diet plan.";
    } 
    else {
        cluster = "Moderate Risk";
        recommendation = "Start exercising and monitor your diet.";
    }

    document.getElementById("result").innerHTML = `
        <h3>Cluster: ${cluster}</h3>
        <p>${recommendation}</p>
    `;
};
