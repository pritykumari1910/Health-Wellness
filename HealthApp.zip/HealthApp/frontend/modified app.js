document.getElementById("healthForm").onsubmit = async function (e) {
    e.preventDefault();

    let data = {
        age: parseInt(document.getElementById("age").value),
        bmi: parseInt(document.getElementById("bmi").value),
        cholesterol: parseInt(document.getElementById("cholesterol").value),
        exercise: parseInt(document.getElementById("exercise").value),
    };

    let response = await fetch("http://localhost:5000/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
    });

    let result = await response.json();

    document.getElementById("result").innerHTML = `
        <h3>Cluster: ${result.cluster}</h3>
        <p>${result.recommendation}</p>
    `;
};
