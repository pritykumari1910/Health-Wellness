from flask import Flask, request, jsonify
from model import predict_cluster
from database import get_db

app = Flask(__name__)

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    age = data["age"]
    bmi = data["bmi"]
    cholesterol = data["cholesterol"]
    exercise = data["exercise"]
    
    cluster, recommendation = predict_cluster([age, bmi, cholesterol, exercise])

    db = get_db()
    db.users.insert_one(data)

    return jsonify({"cluster": cluster, "recommendation": recommendation})

if __name__ == "__main__":
    app.run(debug=True)
