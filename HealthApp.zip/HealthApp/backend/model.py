import numpy as np
from sklearn.mixture import GaussianMixture

def predict_cluster(data):
    X = np.array(data).reshape(1, -1)
    gmm = GaussianMixture(n_components=3, random_state=42)
    gmm.fit([[25, 23, 190, 3], [34, 27, 210, 1], [29, 26, 180, 2]])
    cluster = gmm.predict(X)[0]
    
    if cluster == 0:
        return "Active & Healthy", "Maintain a balanced diet and regular exercise."
    elif cluster == 1:
        return "Moderate Risk", "Start exercising and monitor your diet."
    else:
        return "High Risk", "Consult a doctor and follow a personalized health plan."
